const {
  getFormOptionsService,
  getBranchesService,
  getUserDetailsService,
  validateUserInputService,
  createCompanyService,
  updateUserService,
  uploadUserImageService,
  determineUserStatus,
} = require('./company.service');
const { auditLog } = require('../../utils/audit-log');
const { logApiSuccess, logApiError } = require('../../utils/log');
const AppError = require('../../utils/app-error');

function requestMeta(req) {
  return {
    ip: req.ip,
    method: req.method,
    path: req.originalUrl,
  };
}

/**
 * Get form options for user creation form
 */
async function getFormOptionsHandler(req, res, next) {
  try {
    const { type } = req.query;
    const result = await getFormOptionsService(type);

    logApiSuccess(req, 200, result.data, 'Form options fetched successfully');

    return res.status(200).json(result.data);
  } catch (error) {
    logApiError(req, 400, error.message, 'Form options fetch failed');
    return next(error);
  }
}

/**
 * Get branches based on category and user level
 */
async function getBranchesHandler(req, res, next) {
  try {
    const { branchCategory, userLevel } = req.query;
    const result = await getBranchesService(branchCategory, userLevel);

    logApiSuccess(req, 200, result.data, 'Branches fetched successfully');

    return res.ok(result.data);
  } catch (error) {
    logApiError(req, 400, error.message, 'Branches fetch failed');
    return next(error);
  }
}

/**
 * Get user details by user ID
 */
async function getUserDetailsHandler(req, res, next) {
  try {
    const { userId } = req.query;

    if (!userId) {
      throw new AppError('User ID is required', 400);
    }

    const result = await getUserDetailsService(userId);

    logApiSuccess(req, 200, result.data, `User details fetched for user: ${userId}`);

    return res.ok(result.data);
  } catch (error) {
    logApiError(req, error.statusCode || 400, error.message, 'User details fetch failed');
    return next(error);
  }
}

/**
 * Validate user input
 */
async function validateUserHandler(req, res, next) {
  try {
    const payload = req.body;
    const result = await validateUserInputService(payload);

    logApiSuccess(req, 200, result, 'User validation successful');

    return res.ok(result);
  } catch (error) {
    logApiError(req, error.statusCode || 400, error.message, 'User validation failed');
    return next(error);
  }
}

/**
 * Create new user
 */
async function createCompanyHandler(req, res, next) {
  try {
    const payload = req.body;

    console.log("Company Payload:", payload);

    const result = await createCompanyService(payload);

    auditLog({
      action: "COMPANY_CREATION",
      actor: req.user?.userId || "system",
      module: "companyMaster",
      entityId: payload.compid,
      status: result.success ? "SUCCESS" : "FAILED",
      details: {
        companyName: payload.compname,
        branchName: payload.branchname,
        companyType: payload.companytype,
        errorCode: result.data?.out_ErrorCode,
        errorMsg: result.data?.out_ErrorMsg,
      },
      requestMeta: requestMeta(req),
    });

    logApiSuccess(
      req,
      201,
      result,
      `Company created successfully: ${payload.compid}`
    );

    return res.status(201).json({
      success: true,
      message: result.message,
    });
  } catch (error) {
    logApiError(
      req,
      error.statusCode || 400,
      error.message,
      "Company creation failed"
    );

    auditLog({
      action: "COMPANY_CREATION",
      actor: req.user?.userId || "system",
      module: "companyMaster",
      status: "FAILED",
      details: {
        error: error.message,
      },
      requestMeta: requestMeta(req),
    });

    return next(error);
  }
}

/**
 * Update existing user
 */
async function updateUserHandler(req, res, next) {
  try {
    const payload = req.body;

    if (!payload.userid) {
      throw new AppError('User ID is required for update', 400);
    }

    // Add user info from authenticated request
    payload.insby = req.user?.userId || 'system';
    payload.mode = 2; // Update mode

    const result = await updateUserService(payload);

    auditLog({
      action: 'USER_UPDATE',
      actor: req.user?.userId || 'system',
      module: 'userCreation',
      entityId: result.userId,
      status: result.success ? 'SUCCESS' : 'FAILED',
      details: {
        firstName: payload.firstname,
        lastName: payload.lastname,
        errorCode: result.data?.Out_errorCode,
        errorMsg: result.data?.Out_ErrorMsg,
      },
      requestMeta: requestMeta(req),
    });

    logApiSuccess(req, 200, result, `User updated successfully: ${result.userId}`);

    return res.ok({
      success: true,
      message: result.message,
      userId: result.userId,
    });
  } catch (error) {
    logApiError(req, error.statusCode || 400, error.message, 'User update failed');

    auditLog({
      action: 'USER_UPDATE',
      actor: req.user?.userId || 'system',
      module: 'userCreation',
      status: 'FAILED',
      details: { error: error.message },
      requestMeta: requestMeta(req),
    });

    return next(error);
  }
}

/**
 * Upload user image/document
 */
async function uploadUserImageHandler(req, res, next) {
  try {
    if (!req.file) {
      throw new AppError('File is required', 400);
    }

    const { userId, imagePosition = 1 } = req.body;

    if (!userId) {
      throw new AppError('User ID is required', 400);
    }

    // Determine image type based on MIME type
    let imageType = 'IMAGE';
    if (req.file.mimetype === 'application/pdf') {
      imageType = 'PDF';
    } else if (req.file.mimetype === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
      imageType = 'WORD';
    }

    const result = await uploadUserImageService(userId, req.file.buffer, imageType, parseInt(imagePosition));

    auditLog({
      action: 'IMAGE_UPLOAD',
      actor: req.user?.userId || 'system',
      module: 'userCreation',
      entityId: userId,
      status: 'SUCCESS',
      details: {
        fileName: req.file.originalname,
        fileSize: req.file.size,
        imageType: imageType,
      },
      requestMeta: requestMeta(req),
    });

    logApiSuccess(req, 200, result, `Image uploaded for user: ${userId}`);

    return res.ok(result);
  } catch (error) {
    logApiError(req, error.statusCode || 400, error.message, 'Image upload failed');

    auditLog({
      action: 'IMAGE_UPLOAD',
      actor: req.user?.userId || 'system',
      module: 'userCreation',
      status: 'FAILED',
      details: { error: error.message },
      requestMeta: requestMeta(req),
    });

    return next(error);
  }
}

/**
 * Get user status based on role and device type
 */
async function getUserStatusHandler(req, res, next) {
  try {
    const { roleId, deviceTypeId } = req.query;

    if (!roleId || !deviceTypeId) {
      throw new AppError('Role ID and Device Type ID are required', 400);
    }

    const status = determineUserStatus(parseInt(roleId), parseInt(deviceTypeId));

    logApiSuccess(req, 200, { status }, 'User status determined');

    return res.ok({ status });
  } catch (error) {
    logApiError(req, error.statusCode || 400, error.message, 'User status determination failed');
    return next(error);
  }
}

module.exports = {
  getFormOptionsHandler,
  getBranchesHandler,
  getUserDetailsHandler,
  validateUserHandler,
  createCompanyHandler,
  updateUserHandler,
  uploadUserImageHandler,
  getUserStatusHandler,
};
